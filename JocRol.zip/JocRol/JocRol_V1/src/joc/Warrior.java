/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joc;

import joc.Human;

/**
 *
 * @author alumne
 */
public class Warrior extends Human {
    
    public Warrior(){
        
        System.out.println("CONSTRUCTOR -> He creat un Warrior");
        
    }
    
}
