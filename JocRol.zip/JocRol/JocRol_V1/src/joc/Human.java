/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joc;

import joc.Player;

/**
 *
 * @author alumne
 */
public class Human extends Player {
    
    public Human(){
        
        System.out.println("CONSTRUCTOR -> He creat un Huma");
        
    }
    
}
