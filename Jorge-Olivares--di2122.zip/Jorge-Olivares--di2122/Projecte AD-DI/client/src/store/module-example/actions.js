export function someAction (/* context */) {
}
