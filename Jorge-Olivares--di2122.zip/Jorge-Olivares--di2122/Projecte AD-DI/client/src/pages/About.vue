<template>
    <q-page class="bg-blue text-white text-center q-pa-md flex flex-center">
        <div class="column">
            <div style="margin-top:-100px; margin-left:50px">
                <h2> Acerca De </h2>
            </div>
            <div style="margin-left:100px">
                <h6> Bienvenido/a a  Qualificacions App, esta app ha sido desarrollada para un proyecto de AD-DI, <br/>
                    en IES Jaume II el Just, en Tavernes De La Valldigna, curso 2021-2022 por Jorge Olivares
                </h6>
            </div>
        </div>
    </q-page>
</template>

<script>
export default {

}
</script>
