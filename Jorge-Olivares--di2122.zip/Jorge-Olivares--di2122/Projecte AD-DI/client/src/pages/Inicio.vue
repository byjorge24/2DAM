<template>
    <q-page class="bg-blue text-white text-center q-pa-md flex flex-center">
        <div class="column">
            <div style="margin-top:-100px; margin-left:50px">
                <h2> Bienvenido a Qualificacions App </h2>
            </div>
            <div style="margin-left:100px">
                <h5> Has iniciado sesion </h5>
            </div>
        </div>
    </q-page>
</template>

<script>
export default {
  name: 'Inicio'
}
</script>
