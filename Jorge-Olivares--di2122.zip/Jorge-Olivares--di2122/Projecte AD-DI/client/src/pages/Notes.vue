<template>
    <q-page class="bg-blue text-white text-center q-pa-md flex flex-center">
        <div class="column">
            <div style="margin-top:-100px; margin-left:50px">
                <h2> Apartado Notas </h2>
            </div>
            <div style="margin-left:100px">
                <h5> NOTAS </h5>
            </div>
        </div>
    </q-page>
</template>

<script>
export default {
  name: 'Notes'
}
</script>
