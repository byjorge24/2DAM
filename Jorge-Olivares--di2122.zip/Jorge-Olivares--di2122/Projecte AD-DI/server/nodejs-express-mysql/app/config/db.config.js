module.exports = {
    HOST: "localhost",
    USER: "root",
    PORT: 3308,
    PASSWORD: "root",
    DB: "docencia"
};