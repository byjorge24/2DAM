aficions = ['esports', 'cine', 'teatre']

for i in aficions:
    print(i)