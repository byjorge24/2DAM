for i in range (0,101):
    print(i);